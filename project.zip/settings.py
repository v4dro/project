# Настройки приложения

# Настройки экрана
SCREEN_WIDTH = 1300
SCREEN_HEIGHT = 600
FPS = 60

# Настройки лабиринта
MIN_MAZE_SIZE = 5
MAX_MAZE_SIZE = 31
DEFAULT_MAZE_SIZE = 15

# Настройки сложности
DEFAULT_DIFFICULTY = 1  # 0 - простой, 1 - средний, 2 - сложный
DIFFICULTY_NAMES = ["Простой", "Средний", "Сложный"]

# Настройки алгоритма поиска пути
PATHFINDING_ALGORITHM = "wave"  

# Настройки истории
MAX_HISTORY_SIZE = 10

# Настройки темы
THEME = "light"  # "light" или "dark"

# Настройки анимаций
ANIMATION_SPEED = 10  # Скорость анимации (кадров в секунду)
TRANSITION_SPEED = 0.3  # Скорость перехода между экранами (в секундах)
BUTTON_ANIMATION_SPEED = 0.15  # Скорость анимации кнопок (в секундах)
MAZE_GENERATION_ANIMATION = True  # Анимировать процесс генерации лабиринта
MAZE_SOLVING_ANIMATION = True  # Анимировать процесс решения лабиринта
PARTICLE_EFFECTS = True  # Включить эффекты частиц

# Цвета (светлая тема)
LIGHT_THEME = {
    "BG_COLOR": (240, 245, 255),
    "TEXT_COLOR": (20, 30, 40),
    "BUTTON_COLOR": (180, 200, 220),
    "BUTTON_HOVER_COLOR": (160, 180, 200),
    "BUTTON_ACTIVE_COLOR": (140, 160, 180),
    "MAZE_BG_COLOR": (230, 240, 250),
    "WALL_COLOR": (40, 50, 70),
    "PATH_COLOR": (255, 100, 100),
    "VISITED_COLOR": (100, 149, 237),
    "START_COLOR": (100, 200, 100),
    "END_COLOR": (255, 165, 0),
    "GRID_COLOR": (200, 210, 220),
    "HIGHLIGHT_COLOR": (255, 215, 0),
    "SHADOW_COLOR": (0, 0, 0, 100)
}

# Цвета (темная тема)
DARK_THEME = {
    "BG_COLOR": (30, 35, 45),
    "TEXT_COLOR": (220, 230, 240),
    "BUTTON_COLOR": (60, 70, 80),
    "BUTTON_HOVER_COLOR": (70, 80, 90),
    "BUTTON_ACTIVE_COLOR": (80, 90, 100),
    "MAZE_BG_COLOR": (40, 45, 55),
    "WALL_COLOR": (80, 90, 110),
    "PATH_COLOR": (255, 100, 100),
    "VISITED_COLOR": (70, 100, 180),
    "START_COLOR": (100, 200, 100),
    "END_COLOR": (255, 165, 0),
    "GRID_COLOR": (60, 70, 80),
    "HIGHLIGHT_COLOR": (255, 215, 0),
    "SHADOW_COLOR": (0, 0, 0, 150)
}

# Активная тема
THEME_COLORS = LIGHT_THEME if THEME == "light" else DARK_THEME

# Применение цветов активной темы
BG_COLOR = THEME_COLORS["BG_COLOR"]
TEXT_COLOR = THEME_COLORS["TEXT_COLOR"]
BUTTON_COLOR = THEME_COLORS["BUTTON_COLOR"]
BUTTON_HOVER_COLOR = THEME_COLORS["BUTTON_HOVER_COLOR"]
ACTIVE_BUTTON_COLOR = THEME_COLORS["BUTTON_ACTIVE_COLOR"]
MAZE_BG_COLOR = THEME_COLORS["MAZE_BG_COLOR"]
WALL_COLOR = THEME_COLORS["WALL_COLOR"]
PATH_COLOR = THEME_COLORS["PATH_COLOR"]
VISITED_COLOR = THEME_COLORS["VISITED_COLOR"]
START_COLOR = THEME_COLORS["START_COLOR"]
END_COLOR = THEME_COLORS["END_COLOR"]
GRID_COLOR = THEME_COLORS["GRID_COLOR"]
HIGHLIGHT_COLOR = THEME_COLORS["HIGHLIGHT_COLOR"]
SHADOW_COLOR = THEME_COLORS["SHADOW_COLOR"]

# Размеры ячеек лабиринта
CELL_SIZE = 20
CELL_MARGIN = 2
MAZE_OFFSET_X = 100
MAZE_OFFSET_Y = 80

# Настройки UI
BUTTON_RADIUS = 10  # Скругление углов кнопок
PANEL_RADIUS = 15   # Скругление углов панелей
UI_SHADOW_OFFSET = 5  # Смещение теней для UI элементов
