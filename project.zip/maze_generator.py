import random
import numpy as np

class MazeGenerator:
    def __init__(self):
        self.directions = [(0, 1), (1, 0), (0, -1), (-1, 0)] 
    
    def generate(self, size, difficulty):
        """
        Генерирует лабиринт заданного размера и сложности
        """

        if size % 2 == 0:
            size += 1
            
        maze = np.ones((size, size), dtype=int)
        
        start_x, start_y = 1, 1
        maze[start_y][start_x] = 0

        end_x, end_y = size - 2, size - 2

        self._generate_maze_dfs(maze, start_x, start_y, difficulty)
        
        maze[1][0] = 0 
        maze[size-2][size-1] = 0 
        
        return maze
    
    def _generate_maze_dfs(self, maze, x, y, difficulty):
        """
        Рекурсивно генерирует лабиринт с помощью алгоритма глубинного поиска с возвратом
        """
        directions = self.directions.copy()
        random.shuffle(directions)
        

        branch_chance = 0.1 + difficulty * 0.2 
        
        for dx, dy in directions:
            new_x, new_y = x + dx * 2, y + dy * 2
            
            if 0 < new_x < maze.shape[1] - 1 and 0 < new_y < maze.shape[0] - 1:
                if maze[new_y][new_x] == 1:
                    maze[y + dy][x + dx] = 0
                    maze[new_y][new_x] = 0
                    
                    self._generate_maze_dfs(maze, new_x, new_y, difficulty)
                elif random.random() < branch_chance and maze[y + dy][x + dx] == 1:
                    maze[y + dy][x + dx] = 0
