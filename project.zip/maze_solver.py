import numpy as np
import heapq
from collections import deque

class MazeSolver:
    def __init__(self):
        self.directions = [(0, 1), (1, 0), (0, -1), (-1, 0)] 
        self.algorithm = "dfs" 
    
    def set_algorithm(self, algorithm):
        """
        Устанавливает алгоритм поиска пути
        """
        if algorithm in ["dfs", "astar", "wave"]:
            self.algorithm = algorithm
    
    def solve(self, maze):
        """
        Находит путь от входа до выхода в лабиринте
        """
        start = None
        end = None
        
        for y in range(maze.shape[0]):
            if maze[y][0] == 0:
                start = (y, 0)
            if maze[y][maze.shape[1]-1] == 0:
                end = (y, maze.shape[1]-1)
        
        if start is None:
            start = (1, 1)
        if end is None:
            end = (maze.shape[0]-2, maze.shape[1]-2)
        
        if self.algorithm == "dfs":
            return self._solve_dfs(maze, start, end)
        elif self.algorithm == "astar":
            return self._solve_astar(maze, start, end)
        elif self.algorithm == "wave":
            return self._solve_wave(maze, start, end)
        else:
            return self._solve_dfs(maze, start, end) 
    
    def _solve_dfs(self, maze, start, end):
        """
        Находит путь с помощью алгоритма глубинного поиска (DFS)
        """
        stack = [start]
        visited = set([start])
        parent = {start: None}
        
        while stack:
            current = stack.pop()
            
            if current == end:
                path = []
                while current:
                    path.append(current)
                    current = parent[current]
                return path[::-1] 
            
            y, x = current
            
            for dy, dx in self.directions:
                new_y, new_x = y + dy, x + dx
                
                if 0 <= new_y < maze.shape[0] and 0 <= new_x < maze.shape[1]:
                    if maze[new_y][new_x] == 0 and (new_y, new_x) not in visited:
                        stack.append((new_y, new_x))
                        visited.add((new_y, new_x))
                        parent[(new_y, new_x)] = current
        
        return [] 
    
    def _solve_astar(self, maze, start, end):
        """
        Находит путь с помощью алгоритма A*
        """
        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])
        
        open_set = []
        heapq.heappush(open_set, (0, start)) 
        
        g_score = {start: 0} 
        f_score = {start: heuristic(start, end)} 
        
        closed_set = set()
        parent = {start: None}
        
        while open_set:
            _, current = heapq.heappop(open_set)
            
            if current == end:
                path = []
                while current:
                    path.append(current)
                    current = parent[current]
                return path[::-1] 
            
            closed_set.add(current)
            
            y, x = current
            
            for dy, dx in self.directions:
                new_y, new_x = y + dy, x + dx
                neighbor = (new_y, new_x)
                
                if 0 <= new_y < maze.shape[0] and 0 <= new_x < maze.shape[1]:
                    if maze[new_y][new_x] == 1 or neighbor in closed_set:
                        continue
                    
                    tentative_g_score = g_score[current] + 1
                    
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        parent[neighbor] = current
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = g_score[neighbor] + heuristic(neighbor, end)
                        
                        if neighbor not in [i[1] for i in open_set]:
                            heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        return []  
    
    def _solve_wave(self, maze, start, end):
        """
        Находит путь с помощью волнового алгоритма (BFS)
        """
        queue = deque([start])
        visited = set([start])
        parent = {start: None}
        
        while queue:
            current = queue.popleft()
            
            if current == end:
                path = []
                while current:
                    path.append(current)
                    current = parent[current]
                return path[::-1] 
            
            y, x = current
            
            for dy, dx in self.directions:
                new_y, new_x = y + dy, x + dx
                
                if 0 <= new_y < maze.shape[0] and 0 <= new_x < maze.shape[1]:
                    if maze[new_y][new_x] == 0 and (new_y, new_x) not in visited:
                        queue.append((new_y, new_x))
                        visited.add((new_y, new_x))
                        parent[(new_y, new_x)] = current
        
        return []  
