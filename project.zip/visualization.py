import pygame
import time
import math
import random
from settings import *
from effects import ParticleSystem, AnimationManager, FadeAnimation, MoveAnimation, ScaleAnimation, draw_rounded_rect, draw_button

class Visualization:
    def __init__(self, screen):
        """
        Инициализирует визуализатор
        """
        self.screen = screen
        self.particle_system = ParticleSystem()
        self.animation_manager = AnimationManager()
        
        self.animation_cells = []
        self.animation_index = 0
        self.animation_timer = 0
        self.animation_active = False
        
        self.hover_effects = {}
        self.active_effects = {}
        
        self.transition_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        self.transition_alpha = 0
        self.transition_active = False
        
        self.last_maze = None
        self.last_solution_path = None
        self.last_maze_rect = None
        self.last_cell_size = 0
        self.last_offset_x = 0
        self.last_offset_y = 0
    
    def start_transition(self, callback=None):
        """
        Запускает анимацию перехода между экранами
        """
        fade_in = FadeAnimation(True, TRANSITION_SPEED / 2)
        self.animation_manager.add_animation("transition_in", fade_in)
        
        def transition_middle():
            if callback:
                callback()
            fade_out = FadeAnimation(False, TRANSITION_SPEED / 2)
            self.animation_manager.add_animation("transition_out", fade_out)
        
        fade_in.callback = transition_middle
        self.transition_active = True
    
    def draw_transition(self):
        """
        Отрисовывает эффект перехода между экранами
        """
        if not self.transition_active:
            return
        transition_in = self.animation_manager.get_animation("transition_in")
        transition_out = self.animation_manager.get_animation("transition_out")
        if transition_in:
            alpha = transition_in.get_alpha()
        elif transition_out:
            alpha = transition_out.get_alpha()
        else:
            self.transition_active = False
            return
        w, h = self.screen.get_width(), self.screen.get_height()
        if self.transition_surface.get_width() != w or self.transition_surface.get_height() != h:
            self.transition_surface = pygame.Surface((w, h), pygame.SRCALPHA)
        self.transition_surface.fill((0, 0, 0, alpha))
        self.screen.blit(self.transition_surface, (0, 0))
        if not transition_in and not transition_out:
            self.transition_active = False
    
    def update(self, dt):
        """
        Обновляет анимации и эффекты
        """
        self.particle_system.update(dt)
        
        self.animation_manager.update(dt)
        
        if self.animation_active and self.animation_cells:
            self.animation_timer += dt
            animation_speed = 1.0 / ANIMATION_SPEED
            
            if self.animation_timer >= animation_speed:
                self.animation_timer -= animation_speed
                self.animation_index += 1
                
                if self.animation_index >= len(self.animation_cells):
                    self.animation_active = False
                    self.animation_index = len(self.animation_cells) - 1
                    
                    if PARTICLE_EFFECTS and self.last_maze_rect:
                        for _ in range(20):
                            x = random.randint(self.last_maze_rect.left, self.last_maze_rect.right)
                            y = random.randint(self.last_maze_rect.top, self.last_maze_rect.bottom)
                            color = random.choice([START_COLOR, END_COLOR, PATH_COLOR])
                            self.particle_system.add_particles(x, y, color, count=5)
    
    def start_maze_animation(self, cells, is_solution=False):
        """
        Запускает анимацию генерации или решения лабиринта

        """
        if (is_solution and not MAZE_SOLVING_ANIMATION) or \
           (not is_solution and not MAZE_GENERATION_ANIMATION):
            return
            
        self.animation_cells = cells
        self.animation_index = 0
        self.animation_timer = 0
        self.animation_active = True
    
    def draw_maze(self, maze, solution_path=None, area_rect=None):
        """
        Отрисовывает лабиринт и путь решения с эффектами

        """
        maze_height, maze_width = maze.shape
        if area_rect is not None:
            cell_size = min(
                (area_rect.width - 2 * MAZE_OFFSET_X) // maze_width,
                (area_rect.height - 2 * MAZE_OFFSET_Y) // maze_height
            )
            offset_x = area_rect.left + (area_rect.width - maze_width * cell_size) // 2
            offset_y = area_rect.top + (area_rect.height - maze_height * cell_size) // 2
        else:
            cell_size = min(
                (SCREEN_WIDTH - 2 * MAZE_OFFSET_X) // maze_width,
                (SCREEN_HEIGHT - 2 * MAZE_OFFSET_Y - 80) // maze_height
            )
            offset_x = (SCREEN_WIDTH - maze_width * cell_size) // 2
            offset_y = (SCREEN_HEIGHT - maze_height * cell_size - 80) // 2 + 50
        self.last_maze = maze
        self.last_solution_path = solution_path
        self.last_maze_rect = pygame.Rect(offset_x, offset_y, maze_width * cell_size, maze_height * cell_size)
        self.last_cell_size = cell_size
        self.last_offset_x = offset_x
        self.last_offset_y = offset_y
        shadow_rect = pygame.Rect(
            offset_x + UI_SHADOW_OFFSET, 
            offset_y + UI_SHADOW_OFFSET, 
            maze_width * cell_size, 
            maze_height * cell_size
        )
        draw_rounded_rect(self.screen, (0, 0, 0), shadow_rect, PANEL_RADIUS, 50)
        draw_rounded_rect(self.screen, MAZE_BG_COLOR, self.last_maze_rect, PANEL_RADIUS)
        visited_cells = set()
        if solution_path:
            visited_cells = set(solution_path)
        cells_to_draw = []
        for y in range(maze_height):
            for x in range(maze_width):
                cells_to_draw.append((y, x))
        if self.animation_active and self.animation_cells:
            cells_to_draw = self.animation_cells[:self.animation_index + 1]
        for y, x in cells_to_draw:
            cell_rect = pygame.Rect(
                offset_x + x * cell_size,
                offset_y + y * cell_size,
                cell_size, cell_size
            )
            
            inner_rect = pygame.Rect(
                cell_rect.x + 1,
                cell_rect.y + 1,
                cell_rect.width - 2,
                cell_rect.height - 2
            )
            
            if maze[y][x] == 1:  
                pygame.draw.rect(self.screen, WALL_COLOR, inner_rect, border_radius=2)
                
                highlight_surface = pygame.Surface((inner_rect.width, inner_rect.height // 3), pygame.SRCALPHA)
                for i in range(highlight_surface.get_height()):
                    alpha = 30 - (i / highlight_surface.get_height()) * 30
                    pygame.draw.line(highlight_surface, (255, 255, 255, int(alpha)), 
                                    (0, i), (inner_rect.width, i))
                self.screen.blit(highlight_surface, (inner_rect.x, inner_rect.y))
            else:  
                if (y == 1 and x == 0) or (y == 1 and x == 1):
                    pygame.draw.rect(self.screen, START_COLOR, inner_rect, border_radius=2)
                    
                    if PARTICLE_EFFECTS and random.random() < 0.02:
                        center_x = inner_rect.x + inner_rect.width // 2
                        center_y = inner_rect.y + inner_rect.height // 2
                        self.particle_system.add_particles(center_x, center_y, START_COLOR, count=3, size_range=(1, 3))
                        
                elif (y == maze_height - 2 and x == maze_width - 1) or (y == maze_height - 2 and x == maze_width - 2):  
                    pygame.draw.rect(self.screen, END_COLOR, inner_rect, border_radius=2)
                    
                    if PARTICLE_EFFECTS and random.random() < 0.02:
                        center_x = inner_rect.x + inner_rect.width // 2
                        center_y = inner_rect.y + inner_rect.height // 2
                        self.particle_system.add_particles(center_x, center_y, END_COLOR, count=3, size_range=(1, 3))
                        
                elif solution_path and (y, x) in visited_cells:  
                    pygame.draw.rect(self.screen, PATH_COLOR, inner_rect, border_radius=2)
                    
                    if PARTICLE_EFFECTS and random.random() < 0.01:
                        center_x = inner_rect.x + inner_rect.width // 2
                        center_y = inner_rect.y + inner_rect.height // 2
                        self.particle_system.add_particles(center_x, center_y, PATH_COLOR, count=2, size_range=(1, 2))
                else:
                    pygame.draw.rect(self.screen, MAZE_BG_COLOR, inner_rect, border_radius=2)
        
        self.particle_system.draw(self.screen)
    
    def draw_maze_thumbnail(self, maze, rect, hover=False):
        """
        Отрисовывает миниатюру лабиринта с эффектами

        """
        maze_height, maze_width = maze.shape
        
        cell_width = rect.width / maze_width
        cell_height = rect.height / maze_height
        
        shadow_rect = pygame.Rect(rect.x + 3, rect.y + 3, rect.width, rect.height)
        draw_rounded_rect(self.screen, (0, 0, 0), shadow_rect, 5, 50)
        draw_rounded_rect(self.screen, MAZE_BG_COLOR, rect, 5)
        
        if hover:
            highlight_rect = pygame.Rect(rect.x - 2, rect.y - 2, rect.width + 4, rect.height + 4)
            pygame.draw.rect(self.screen, HIGHLIGHT_COLOR, highlight_rect, width=2, border_radius=6)
        
        for y in range(maze_height):
            for x in range(maze_width):
                if maze_width > 20 and (x % 2 != 0 or y % 2 != 0) and not ((y == 1 and x == 0) or 
                       (y == maze_height - 2 and x == maze_width - 1)):
                    continue
                    
                cell_rect = pygame.Rect(
                    rect.x + x * cell_width,
                    rect.y + y * cell_height,
                    max(1, cell_width),
                    max(1, cell_height)
                )
                
                if maze[y][x] == 1:  
                    pygame.draw.rect(self.screen, WALL_COLOR, cell_rect)
                else:  
                    if (y == 1 and x == 0) or (y == 1 and x == 1):  
                        pygame.draw.rect(self.screen, START_COLOR, cell_rect)
                    elif (y == maze_height - 2 and x == maze_width - 1) or (y == maze_height - 2 and x == maze_width - 2): 
                        pygame.draw.rect(self.screen, END_COLOR, cell_rect)
                    else:
                        pass
