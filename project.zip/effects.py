import pygame
import random
import math
from settings import *

class Particle:
    def __init__(self, x, y, color, size=3, lifetime=1.0, speed=1.0, direction=None):
        self.x = x
        self.y = y
        self.original_color = color
        self.color = color
        self.size = size
        self.original_size = size
        self.lifetime = lifetime
        self.age = 0
        self.speed = speed
        
        if direction is None:
            angle = random.uniform(0, 2 * math.pi)
            self.dx = math.cos(angle) * speed
            self.dy = math.sin(angle) * speed
        else:
            self.dx = direction[0] * speed
            self.dy = direction[1] * speed
    
    def update(self, dt):
        self.age += dt
        
        self.x += self.dx * dt
        self.y += self.dy * dt
        
        life_ratio = 1 - (self.age / self.lifetime)
        self.size = self.original_size * life_ratio
        
        r, g, b = self.original_color
        a = int(255 * life_ratio)
        self.color = (r, g, b, a)
        
        return self.age < self.lifetime
    
    def draw(self, surface):
        if self.size < 1:
            return
            
        s = pygame.Surface((int(self.size * 2), int(self.size * 2)), pygame.SRCALPHA)
        pygame.draw.circle(s, self.color, (int(self.size), int(self.size)), int(self.size))
        surface.blit(s, (int(self.x - self.size), int(self.y - self.size)))

class ParticleSystem:
    def __init__(self):
        self.particles = []
    
    def add_particle(self, x, y, color, size=3, lifetime=1.0, speed=1.0, direction=None):
        self.particles.append(Particle(x, y, color, size, lifetime, speed, direction))
    
    def add_particles(self, x, y, color, count=10, size_range=(2, 5), lifetime_range=(0.5, 1.5), speed_range=(0.5, 2.0)):
        for _ in range(count):
            size = random.uniform(size_range[0], size_range[1])
            lifetime = random.uniform(lifetime_range[0], lifetime_range[1])
            speed = random.uniform(speed_range[0], speed_range[1])
            self.add_particle(x, y, color, size, lifetime, speed)
    
    def update(self, dt):
        self.particles = [p for p in self.particles if p.update(dt)]
    
    def draw(self, surface):
        for particle in self.particles:
            particle.draw(surface)
    
    def clear(self):
        self.particles = []

class Animation:
    def __init__(self, duration=1.0, loop=False, callback=None):
        self.duration = duration
        self.elapsed_time = 0
        self.loop = loop
        self.callback = callback
        self.completed = False
    
    def update(self, dt):
        if self.completed and not self.loop:
            return True
            
        self.elapsed_time += dt
        
        if self.elapsed_time >= self.duration:
            if self.loop:
                self.elapsed_time %= self.duration
            else:
                self.elapsed_time = self.duration
                self.completed = True
                if self.callback:
                    self.callback()
        
        return self.completed
    
    def get_progress(self):
        return min(self.elapsed_time / self.duration, 1.0)
    
    def reset(self):
        self.elapsed_time = 0
        self.completed = False

class FadeAnimation(Animation):
    def __init__(self, fade_in=True, duration=0.5, callback=None):
        super().__init__(duration, False, callback)
        self.fade_in = fade_in
    
    def get_alpha(self):
        progress = self.get_progress()
        return int(255 * progress) if self.fade_in else int(255 * (1 - progress))

class MoveAnimation(Animation):
    def __init__(self, start_pos, end_pos, duration=0.5, easing="linear", callback=None):
        super().__init__(duration, False, callback)
        self.start_pos = start_pos
        self.end_pos = end_pos
        self.easing = easing
    
    def get_position(self):
        progress = self.get_progress()
        
        if self.easing == "ease_in":
            progress = progress * progress
        elif self.easing == "ease_out":
            progress = 1 - (1 - progress) * (1 - progress)
        elif self.easing == "ease_in_out":
            progress = 0.5 * (math.sin((progress - 0.5) * math.pi) + 1)
        
        x = self.start_pos[0] + (self.end_pos[0] - self.start_pos[0]) * progress
        y = self.start_pos[1] + (self.end_pos[1] - self.start_pos[1]) * progress
        return (x, y)

class ScaleAnimation(Animation):
    def __init__(self, start_scale, end_scale, duration=0.5, easing="linear", callback=None):
        super().__init__(duration, False, callback)
        self.start_scale = start_scale
        self.end_scale = end_scale
        self.easing = easing
    
    def get_scale(self):
        progress = self.get_progress()
        
        if self.easing == "ease_in":
            progress = progress * progress
        elif self.easing == "ease_out":
            progress = 1 - (1 - progress) * (1 - progress)
        elif self.easing == "ease_in_out":
            progress = 0.5 * (math.sin((progress - 0.5) * math.pi) + 1)
        
        return self.start_scale + (self.end_scale - self.start_scale) * progress

class AnimationManager:
    def __init__(self):
        self.animations = {}
    
    def add_animation(self, name, animation):
        self.animations[name] = animation
    
    def update(self, dt):
        animation_names = list(self.animations.keys())
        completed = []
        
        for name in animation_names:
            if name in self.animations:
                animation = self.animations[name]
                if animation.update(dt) and not animation.loop:
                    completed.append(name)
        
        for name in completed:
            if name in self.animations:
                del self.animations[name]
    
    def get_animation(self, name):
        return self.animations.get(name)
    
    def clear(self):
        self.animations = {}

def draw_rounded_rect(surface, color, rect, radius, alpha=255):
    rect = pygame.Rect(rect)
    
    temp_surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    
    pygame.draw.rect(temp_surface, (*color[:3], alpha), (0, 0, rect.width, rect.height), border_radius=radius)
    
    surface.blit(temp_surface, rect.topleft)

def draw_button(surface, rect, text, font, color=None, hover=False, active=False, radius=BUTTON_RADIUS):
    if color is None:
        if active:
            color = ACTIVE_BUTTON_COLOR
        elif hover:
            color = BUTTON_HOVER_COLOR
        else:
            color = BUTTON_COLOR
    
    shadow_rect = pygame.Rect(rect.x + UI_SHADOW_OFFSET, rect.y + UI_SHADOW_OFFSET, rect.width, rect.height)
    draw_rounded_rect(surface, (0, 0, 0), shadow_rect, radius, 50)
    
    draw_rounded_rect(surface, color, rect, radius)
    
    highlight_rect = pygame.Rect(rect.x, rect.y, rect.width, rect.height // 2)
    highlight_surface = pygame.Surface((rect.width, rect.height // 2), pygame.SRCALPHA)
    for i in range(highlight_rect.height):
        alpha = 50 - (i / highlight_rect.height) * 50
        pygame.draw.line(highlight_surface, (*HIGHLIGHT_COLOR[:3], int(alpha)), 
                         (0, i), (rect.width, i))
    
    highlight_mask = pygame.Surface((rect.width, rect.height // 2), pygame.SRCALPHA)
    pygame.draw.rect(highlight_mask, (255, 255, 255), (0, 0, rect.width, rect.height // 2), border_radius=radius)
    highlight_surface.blit(highlight_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    
    surface.blit(highlight_surface, highlight_rect)
    
    text_surface = font.render(text, True, TEXT_COLOR)
    text_rect = text_surface.get_rect(center=rect.center)
    surface.blit(text_surface, text_rect)
    
    return rect
