import pygame
import sys
import numpy as np
import time
import random
import math
from settings import *
from maze_generator import MazeGenerator
from maze_solver import MazeSolver
from visualization import Visualization
from effects import draw_button, draw_rounded_rect, ParticleSystem, AnimationManager

class MazeApp:
    def __init__(self):
        pygame.init()
        self.fullscreen = False
        self.windowed_size = (SCREEN_WIDTH, SCREEN_HEIGHT)
        self.screen = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)
        pygame.display.set_caption("Генератор лабиринтов")
        self.clock = pygame.time.Clock()
        
        icon = pygame.Surface((32, 32))
        icon.fill(WALL_COLOR)
        for i in range(4):
            for j in range(4):
                if (i + j) % 2 == 0:
                    pygame.draw.rect(icon, MAZE_BG_COLOR, (i*8, j*8, 8, 8))
        pygame.display.set_icon(icon)
        
        self.maze_size = DEFAULT_MAZE_SIZE
        self.difficulty = DEFAULT_DIFFICULTY
        
        self.generator = MazeGenerator()
        self.solver = MazeSolver()
        self.solver.set_algorithm(PATHFINDING_ALGORITHM)  
        self.visualization = Visualization(self.screen)
        
        self.maze = None
        self.solution_path = None
        self.current_screen = "generation"  
        self.previous_screen = "generation"  
        
        self.history = []  
        
        self.font_large = pygame.font.SysFont("Arial", 48, bold=True)
        self.font_medium = pygame.font.SysFont("Arial", 36)
        self.font_small = pygame.font.SysFont("Arial", 24)
        
        self.generate_button_rect = None
        self.size_increase_rect = None
        self.size_decrease_rect = None
        self.difficulty_increase_rect = None
        self.difficulty_decrease_rect = None
        self.history_button_rect = None
        self.settings_button_rect = None
        self.solve_button_rect = None
        self.regenerate_button_rect = None
        self.back_button_rect = None
        self.history_maze_rects = []
        
        self.dfs_rect = None
        self.astar_rect = None
        self.wave_rect = None
        self.theme_toggle_rect = None
        
        self.hover_button = None
        self.active_button = None
        
        self.particle_system = ParticleSystem()
        self.animation_manager = AnimationManager()
        
        self.last_time = time.time()
        self.transition_active = False
        self.generating_maze = False
        self.solving_maze = False
        
        self.generation_progress = 0
        self.solving_progress = 0
        
    def run(self):
        running = True
        while running:
            current_time = time.time()
            dt = current_time - self.last_time
            self.last_time = current_time
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11:
                        self.toggle_fullscreen()
                elif event.type == pygame.VIDEORESIZE:
                    self.handle_resize(event.w, event.h)
                self.handle_event(event)
            self.update(dt)
            self.render()
            pygame.display.flip()
            self.clock.tick(FPS)
        pygame.quit()
        sys.exit()
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            mouse_pos = pygame.mouse.get_pos()
            self.hover_button = None
            
            if self.current_screen == "generation":
                buttons = [
                    self.generate_button_rect, self.size_increase_rect, self.size_decrease_rect,
                    self.difficulty_increase_rect, self.difficulty_decrease_rect,
                    self.history_button_rect, self.settings_button_rect
                ]
                for button in buttons:
                    if button and self.is_button_clicked(mouse_pos, button):
                        self.hover_button = button
                        if PARTICLE_EFFECTS and random.random() < 0.05:
                            x = random.randint(button.left, button.right)
                            y = random.randint(button.top, button.bottom)
                            self.particle_system.add_particles(x, y, HIGHLIGHT_COLOR, count=2, size_range=(1, 3))
                        break
            
            elif self.current_screen == "gameplay":
                buttons = [self.solve_button_rect, self.regenerate_button_rect, self.back_button_rect]
                for button in buttons:
                    if button and self.is_button_clicked(mouse_pos, button):
                        self.hover_button = button
                        if PARTICLE_EFFECTS and random.random() < 0.05:
                            x = random.randint(button.left, button.right)
                            y = random.randint(button.top, button.bottom)
                            self.particle_system.add_particles(x, y, HIGHLIGHT_COLOR, count=2, size_range=(1, 3))
                        break
            
            elif self.current_screen == "history":
                if self.back_button_rect and self.is_button_clicked(mouse_pos, self.back_button_rect):
                    self.hover_button = self.back_button_rect
                else:
                    for i, rect in enumerate(self.history_maze_rects):
                        if i < len(self.history) and self.is_button_clicked(mouse_pos, rect):
                            self.hover_button = rect
                            break
            
            elif self.current_screen == "settings":
                buttons = [self.back_button_rect, self.dfs_rect, self.astar_rect, self.wave_rect, self.theme_toggle_rect]
                for button in buttons:
                    if button and self.is_button_clicked(mouse_pos, button):
                        self.hover_button = button
                        if PARTICLE_EFFECTS and random.random() < 0.05:
                            x = random.randint(button.left, button.right)
                            y = random.randint(button.top, button.bottom)
                            self.particle_system.add_particles(x, y, HIGHLIGHT_COLOR, count=2, size_range=(1, 3))
                        break
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.current_screen != "generation":
                    self.previous_screen = self.current_screen
                    self.transition_to_screen("generation")
                else:
                    pass
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active_button = self.hover_button
            mouse_pos = pygame.mouse.get_pos()
            
            if PARTICLE_EFFECTS and self.hover_button:
                for _ in range(10):
                    x = random.randint(self.hover_button.left, self.hover_button.right)
                    y = random.randint(self.hover_button.top, self.hover_button.bottom)
                    self.particle_system.add_particles(x, y, HIGHLIGHT_COLOR, count=3, size_range=(2, 5))
            
            if self.current_screen == "generation":
                if self.is_button_clicked(mouse_pos, self.generate_button_rect):
                    self.generate_maze()
                    self.transition_to_screen("gameplay")
                elif self.is_button_clicked(mouse_pos, self.size_increase_rect):
                    self.increase_maze_size()
                elif self.is_button_clicked(mouse_pos, self.size_decrease_rect):
                    self.decrease_maze_size()
                elif self.is_button_clicked(mouse_pos, self.difficulty_increase_rect):
                    self.increase_difficulty()
                elif self.is_button_clicked(mouse_pos, self.difficulty_decrease_rect):
                    self.decrease_difficulty()
                elif self.is_button_clicked(mouse_pos, self.history_button_rect):
                    self.transition_to_screen("history")
                elif self.is_button_clicked(mouse_pos, self.settings_button_rect):
                    self.transition_to_screen("settings")
            
            elif self.current_screen == "gameplay":
                if self.is_button_clicked(mouse_pos, self.solve_button_rect):
                    self.solve_maze()
                elif self.is_button_clicked(mouse_pos, self.regenerate_button_rect):
                    self.generate_maze()
                elif self.is_button_clicked(mouse_pos, self.back_button_rect):
                    self.transition_to_screen("generation")
            
            elif self.current_screen == "history":
                if self.is_button_clicked(mouse_pos, self.back_button_rect):
                    self.transition_to_screen("generation")
                for i, rect in enumerate(self.history_maze_rects):
                    if self.is_button_clicked(mouse_pos, rect) and i < len(self.history):
                        self.maze = self.history[i]["maze"]
                        self.solution_path = None
                        self.transition_to_screen("gameplay")
            
            elif self.current_screen == "settings":
                if self.is_button_clicked(mouse_pos, self.back_button_rect):
                    self.transition_to_screen("generation")
                elif self.is_button_clicked(mouse_pos, self.dfs_rect):
                    self.solver.set_algorithm("dfs")
                elif self.is_button_clicked(mouse_pos, self.astar_rect):
                    self.solver.set_algorithm("astar")
                elif self.is_button_clicked(mouse_pos, self.wave_rect):
                    self.solver.set_algorithm("wave")
                elif self.is_button_clicked(mouse_pos, self.theme_toggle_rect):
                    self.toggle_theme()
        
        if event.type == pygame.MOUSEBUTTONUP:
            self.active_button = None
    
    def transition_to_screen(self, screen_name):
        """
        Переход к новому экрану с анимацией
        
        Args:
            screen_name (str): Имя нового экрана
        """
        self.previous_screen = self.current_screen
        
        def change_screen():
            self.current_screen = screen_name
        
        self.visualization.start_transition(change_screen)
        self.transition_active = True
    
    def toggle_theme(self):
        """
        Переключает тему между светлой и темной
        """
        global THEME, THEME_COLORS, BG_COLOR, TEXT_COLOR, BUTTON_COLOR, BUTTON_HOVER_COLOR, ACTIVE_BUTTON_COLOR
        global MAZE_BG_COLOR, WALL_COLOR, PATH_COLOR, VISITED_COLOR, START_COLOR, END_COLOR, GRID_COLOR, HIGHLIGHT_COLOR
        
        THEME = "dark" if THEME == "light" else "light"
        THEME_COLORS = DARK_THEME if THEME == "dark" else LIGHT_THEME
        
        BG_COLOR = THEME_COLORS["BG_COLOR"]
        TEXT_COLOR = THEME_COLORS["TEXT_COLOR"]
        BUTTON_COLOR = THEME_COLORS["BUTTON_COLOR"]
        BUTTON_HOVER_COLOR = THEME_COLORS["BUTTON_HOVER_COLOR"]
        ACTIVE_BUTTON_COLOR = THEME_COLORS["BUTTON_ACTIVE_COLOR"]
        MAZE_BG_COLOR = THEME_COLORS["MAZE_BG_COLOR"]
        WALL_COLOR = THEME_COLORS["WALL_COLOR"]
        PATH_COLOR = THEME_COLORS["PATH_COLOR"]
        VISITED_COLOR = THEME_COLORS["VISITED_COLOR"]
        START_COLOR = THEME_COLORS["START_COLOR"]
        END_COLOR = THEME_COLORS["END_COLOR"]
        GRID_COLOR = THEME_COLORS["GRID_COLOR"]
        HIGHLIGHT_COLOR = THEME_COLORS["HIGHLIGHT_COLOR"]
        
        if PARTICLE_EFFECTS:
            for _ in range(50):
                x = random.randint(0, SCREEN_WIDTH)
                y = random.randint(0, SCREEN_HEIGHT)
                color = random.choice([BUTTON_COLOR, TEXT_COLOR, HIGHLIGHT_COLOR])
                self.particle_system.add_particles(x, y, color, count=3, size_range=(2, 5))
    
    def update(self, dt):
        """
        Обновляет состояние приложения
        
        Args:
            dt (float): Время, прошедшее с последнего обновления
        """
        self.particle_system.update(dt)
        
        self.animation_manager.update(dt)
        
        self.visualization.update(dt)
    
    def render(self):
        """
        Отрисовывает интерфейс приложения
        """
        self.screen.fill(BG_COLOR)
        
        if self.current_screen == "generation":
            self.render_generation_screen()
        elif self.current_screen == "gameplay":
            self.render_gameplay_screen()
        elif self.current_screen == "history":
            self.render_history_screen()
        elif self.current_screen == "settings":
            self.render_settings_screen()
        
        self.particle_system.draw(self.screen)
        
        self.visualization.draw_transition()
    
    def render_generation_screen(self):
        """
        Отрисовывает экран генерации лабиринта с анимациями и эффектами
        """
        width, height = self.screen.get_width(), self.screen.get_height()

        min_panel_w, min_panel_h = 420, 370
        panel_w, panel_h = max(int(width * 0.38), min_panel_w), max(int(height * 0.55), min_panel_h)

        panel_x = (width - panel_w) // 2
        panel_y = (height - panel_h) // 2 - 30 
        main_panel = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
        shadow_rect = pygame.Rect(main_panel.x + UI_SHADOW_OFFSET, main_panel.y + UI_SHADOW_OFFSET, main_panel.width, main_panel.height)
        draw_rounded_rect(self.screen, (0, 0, 0), shadow_rect, PANEL_RADIUS, 50)
        draw_rounded_rect(self.screen, MAZE_BG_COLOR, main_panel, PANEL_RADIUS)

        title = self.font_large.render("Создать лабиринт", True, TEXT_COLOR)
        title_shadow = self.font_large.render("Создать лабиринт", True, (0, 0, 0, 100))
        title_rect = title.get_rect(center=(width // 2, panel_y + int(panel_h * 0.13)))
        self.screen.blit(title_shadow, (title_rect.x + 2, title_rect.y + 2))
        self.screen.blit(title, title_rect)

        line_w = int(panel_w * 0.6)
        line_rect = pygame.Rect((width - line_w) // 2, title_rect.bottom + 5, line_w, 2)
        pygame.draw.rect(self.screen, HIGHLIGHT_COLOR, line_rect)

        size_text = self.font_medium.render(f"Размер: {self.maze_size}x{self.maze_size}", True, TEXT_COLOR)
        size_y = panel_y + int(panel_h * 0.28)
        size_rect = size_text.get_rect(center=(width // 2, size_y))
        self.screen.blit(size_text, size_rect)
        btn_side = max(int(panel_w * 0.08), 32)
        self.size_decrease_rect = pygame.Rect(size_rect.left - btn_side - 10, size_y - btn_side // 2, btn_side, btn_side)
        self.size_increase_rect = pygame.Rect(size_rect.right + 10, size_y - btn_side // 2, btn_side, btn_side)
        draw_button(self.screen, self.size_decrease_rect, "-", self.font_medium, hover=self.hover_button == self.size_decrease_rect, active=self.active_button == self.size_decrease_rect)
        draw_button(self.screen, self.size_increase_rect, "+", self.font_medium, hover=self.hover_button == self.size_increase_rect, active=self.active_button == self.size_increase_rect)

        diff_text = self.font_medium.render(f"Сложность: {DIFFICULTY_NAMES[self.difficulty]}", True, TEXT_COLOR)
        diff_y = panel_y + int(panel_h * 0.42)
        diff_rect = diff_text.get_rect(center=(width // 2, diff_y))
        self.screen.blit(diff_text, diff_rect)
        self.difficulty_decrease_rect = pygame.Rect(diff_rect.left - btn_side - 10, diff_y - btn_side // 2, btn_side, btn_side)
        self.difficulty_increase_rect = pygame.Rect(diff_rect.right + 10, diff_y - btn_side // 2, btn_side, btn_side)
        draw_button(self.screen, self.difficulty_decrease_rect, "-", self.font_medium, hover=self.hover_button == self.difficulty_decrease_rect, active=self.active_button == self.difficulty_decrease_rect)
        draw_button(self.screen, self.difficulty_increase_rect, "+", self.font_medium, hover=self.hover_button == self.difficulty_increase_rect, active=self.active_button == self.difficulty_increase_rect)

        btn_w, btn_h = max(int(panel_w * 0.45), 120), max(int(panel_h * 0.13), 44)
        btn_x = (width - btn_w) // 2
        btn_y = panel_y + int(panel_h * 0.58)
        self.generate_button_rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
        draw_button(self.screen, self.generate_button_rect, "Создать", self.font_medium, hover=self.hover_button == self.generate_button_rect, active=self.active_button == self.generate_button_rect)

        preview_size = max(int(panel_w * 0.32), 80)
        preview_x = (width - preview_size) // 2
        preview_y = btn_y + btn_h + 10
        if preview_y + preview_size > panel_y + panel_h - 10:
            preview_size = max(panel_y + panel_h - preview_y - 10, 40)
        preview_rect = pygame.Rect(preview_x, preview_y, preview_size, preview_size)
        shadow_rect = pygame.Rect(preview_rect.x + 3, preview_rect.y + 3, preview_rect.width, preview_rect.height)
        draw_rounded_rect(self.screen, (0, 0, 0), shadow_rect, 5, 50)
        draw_rounded_rect(self.screen, MAZE_BG_COLOR, preview_rect, 5)
        if self.maze is None:
            question_text = self.font_large.render("?", True, TEXT_COLOR)
            self.screen.blit(question_text, question_text.get_rect(center=preview_rect.center))
        else:
            try:
                self.visualization.draw_maze_thumbnail(self.maze, preview_rect)
            except Exception:
                question_text = self.font_large.render("?", True, TEXT_COLOR)
                self.screen.blit(question_text, question_text.get_rect(center=preview_rect.center))

        nav_y = panel_y + panel_h + 18
        nav_w = max(int(panel_w * 0.32), 100)
        nav_h = max(int(panel_h * 0.13), 36)
        nav_gap = 18
        total_nav_w = nav_w * 2 + nav_gap
        nav_start_x = (width - total_nav_w) // 2
        self.history_button_rect = pygame.Rect(nav_start_x, nav_y, nav_w, nav_h)
        self.settings_button_rect = pygame.Rect(nav_start_x + nav_w + nav_gap, nav_y, nav_w, nav_h)
        draw_button(self.screen, self.history_button_rect, "История", self.font_small, hover=self.hover_button == self.history_button_rect, active=self.active_button == self.history_button_rect)
        draw_button(self.screen, self.settings_button_rect, "Настройки", self.font_small, hover=self.hover_button == self.settings_button_rect, active=self.active_button == self.settings_button_rect)
    
    def render_gameplay_screen(self):
        width, height = self.screen.get_width(), self.screen.get_height()

        title = self.font_large.render("Лабиринт: Поиск выхода", True, TEXT_COLOR)
        title_rect = title.get_rect(center=(width // 2, int(height * 0.06)))
        self.screen.blit(title, title_rect)

        maze_area_top = title_rect.bottom + 20
        maze_area_height = height - maze_area_top - int(height * 0.15)
        maze_area_rect = pygame.Rect(0, maze_area_top, width, maze_area_height)
        if self.maze is not None:
            self.visualization.draw_maze(self.maze, self.solution_path, area_rect=maze_area_rect)

        btn_w = int(width * 0.13)
        btn_h = int(height * 0.07)
        btn_margin = int(width * 0.025)
        total_width = 3 * btn_w + 2 * btn_margin
        start_x = (width - total_width) // 2
        y = int(height * 0.89)
        self.solve_button_rect = pygame.Rect(start_x, y, btn_w, btn_h)
        self.regenerate_button_rect = pygame.Rect(start_x + btn_w + btn_margin, y, btn_w, btn_h)
        self.back_button_rect = pygame.Rect(start_x + 2 * (btn_w + btn_margin), y, btn_w, btn_h)
        draw_button(self.screen, self.solve_button_rect, "Решить", self.font_small, hover=self.hover_button == self.solve_button_rect, active=self.active_button == self.solve_button_rect)
        draw_button(self.screen, self.regenerate_button_rect, "Обновить", self.font_small, hover=self.hover_button == self.regenerate_button_rect, active=self.active_button == self.regenerate_button_rect)
        draw_button(self.screen, self.back_button_rect, "Назад", self.font_small, hover=self.hover_button == self.back_button_rect, active=self.active_button == self.back_button_rect)
    
    def render_history_screen(self):
        width, height = self.screen.get_width(), self.screen.get_height()
        title = self.font_large.render("История лабиринтов", True, TEXT_COLOR)
        title_rect = title.get_rect(center=(width // 2, int(height * 0.06)))
        self.screen.blit(title, title_rect)
        self.history_maze_rects = []
        if len(self.history) == 0:
            no_history_text = self.font_medium.render("История пуста", True, TEXT_COLOR)
            self.screen.blit(no_history_text, no_history_text.get_rect(center=(width // 2, height // 2)))
        else:
            maze_w = int(width * 0.13)
            maze_h = int(height * 0.18)
            maze_margin = int(width * 0.025)
            mazes_per_row = max(1, width // (maze_w + maze_margin))
            for i, maze_data in enumerate(self.history):
                row = i // mazes_per_row
                col = i % mazes_per_row
                x = (width - (mazes_per_row * maze_w + (mazes_per_row - 1) * maze_margin)) // 2 + col * (maze_w + maze_margin)
                y = int(height * 0.13) + row * (maze_h + maze_margin + 40)
                maze_rect = pygame.Rect(x, y, maze_w, maze_h)
                self.history_maze_rects.append(maze_rect)
                pygame.draw.rect(self.screen, MAZE_BG_COLOR, maze_rect)
                self.visualization.draw_maze_thumbnail(maze_data["maze"], maze_rect)
                info_text = self.font_small.render(f"{maze_data['size']}x{maze_data['size']} - {DIFFICULTY_NAMES[maze_data['difficulty']]}", True, TEXT_COLOR)
                self.screen.blit(info_text, info_text.get_rect(center=(x + maze_w // 2, y + maze_h + 20)))
        btn_w = int(width * 0.13)
        btn_h = int(height * 0.07)
        y = int(height * 0.89)
        self.back_button_rect = pygame.Rect((width - btn_w) // 2, y, btn_w, btn_h)
        draw_button(self.screen, self.back_button_rect, "Назад", self.font_small, hover=self.hover_button == self.back_button_rect, active=self.active_button == self.back_button_rect)
    
    def render_settings_screen(self):
        width, height = self.screen.get_width(), self.screen.get_height()
        panel_w, panel_h = int(width * 0.38), int(height * 0.55)
        panel_x = (width - panel_w) // 2
        panel_y = int(height * 0.05)
        main_panel = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
        shadow_rect = pygame.Rect(main_panel.x + UI_SHADOW_OFFSET, main_panel.y + UI_SHADOW_OFFSET, main_panel.width, main_panel.height)
        draw_rounded_rect(self.screen, (0, 0, 0), shadow_rect, PANEL_RADIUS, 50)
        draw_rounded_rect(self.screen, MAZE_BG_COLOR, main_panel, PANEL_RADIUS)
        title = self.font_large.render("Настройки", True, TEXT_COLOR)
        title_shadow = self.font_large.render("Настройки", True, (0, 0, 0, 100))
        title_rect = title.get_rect(center=(width // 2, panel_y + int(panel_h * 0.12)))
        self.screen.blit(title_shadow, (title_rect.x + 2, title_rect.y + 2))
        self.screen.blit(title, title_rect)
        
        line_w = int(panel_w * 0.6)
        line_rect = pygame.Rect((width - line_w) // 2, title_rect.bottom + 5, line_w, 2)
        pygame.draw.rect(self.screen, HIGHLIGHT_COLOR, line_rect)
        
        alg_title = self.font_medium.render("Алгоритм поиска пути:", True, TEXT_COLOR)
        alg_rect = alg_title.get_rect(center=(width // 2, panel_y + int(panel_h * 0.32)))
        self.screen.blit(alg_title, alg_rect)
        btn_w = int(panel_w * 0.22)
        btn_h = int(panel_h * 0.13)
        y = panel_y + int(panel_h * 0.42)
        self.dfs_rect = pygame.Rect(width // 2 - btn_w - btn_w // 2 - 10, y, btn_w, btn_h)
        self.astar_rect = pygame.Rect(width // 2 - btn_w // 2, y, btn_w, btn_h)
        self.wave_rect = pygame.Rect(width // 2 + btn_w // 2 + 10, y, btn_w, btn_h)
        draw_button(self.screen, self.dfs_rect, "DFS", self.font_small, color=ACTIVE_BUTTON_COLOR if self.solver.algorithm == "dfs" else None, hover=self.hover_button == self.dfs_rect, active=self.active_button == self.dfs_rect)
        draw_button(self.screen, self.astar_rect, "A*", self.font_small, color=ACTIVE_BUTTON_COLOR if self.solver.algorithm == "astar" else None, hover=self.hover_button == self.astar_rect, active=self.active_button == self.astar_rect)
        draw_button(self.screen, self.wave_rect, "Волна", self.font_small, color=ACTIVE_BUTTON_COLOR if self.solver.algorithm == "wave" else None, hover=self.hover_button == self.wave_rect, active=self.active_button == self.wave_rect)
        
        theme_title = self.font_medium.render("Тема:", True, TEXT_COLOR)
        theme_rect = theme_title.get_rect(center=(width // 2, panel_y + int(panel_h * 0.62)))
        self.screen.blit(theme_title, theme_rect)
        theme_btn_w = int(panel_w * 0.45)
        theme_btn_h = int(panel_h * 0.13)
        theme_btn_y = panel_y + int(panel_h * 0.7)
        self.theme_toggle_rect = pygame.Rect((width - theme_btn_w) // 2, theme_btn_y, theme_btn_w, theme_btn_h)
        theme_text = "Светлая" if THEME == "light" else "Темная"
        draw_button(self.screen, self.theme_toggle_rect, theme_text, self.font_small, hover=self.hover_button == self.theme_toggle_rect, active=self.active_button == self.theme_toggle_rect)
        
        back_btn_w = int(panel_w * 0.32)
        back_btn_h = int(panel_h * 0.13)
        back_btn_y = panel_y + panel_h + int(height * 0.03)
        self.back_button_rect = pygame.Rect((width - back_btn_w) // 2, back_btn_y, back_btn_w, back_btn_h)
        draw_button(self.screen, self.back_button_rect, "Назад", self.font_small, hover=self.hover_button == self.back_button_rect, active=self.active_button == self.back_button_rect)
    
    def generate_maze(self):
        """
        Генерирует новый лабиринт и добавляет его в историю
        """
        self.maze = self.generator.generate(self.maze_size, self.difficulty)
        self.solution_path = None
        
        maze_data = {
            "maze": self.maze,
            "size": self.maze_size,
            "difficulty": self.difficulty,
            "solution_path": None
        }
        
        self.history.insert(0, maze_data)
        if len(self.history) > MAX_HISTORY_SIZE:
            self.history.pop()
    
    def solve_maze(self):
        if self.maze is not None:
            self.solution_path = self.solver.solve(self.maze)
            
            if len(self.history) > 0 and np.array_equal(self.history[0]["maze"], self.maze):
                self.history[0]["solution_path"] = self.solution_path
    
    def increase_maze_size(self):
        if self.maze_size < MAX_MAZE_SIZE:
            self.maze_size += 2
    
    def decrease_maze_size(self):
        if self.maze_size > MIN_MAZE_SIZE:
            self.maze_size -= 2
    
    def increase_difficulty(self):
        if self.difficulty < len(DIFFICULTY_NAMES) - 1:
            self.difficulty += 1
    
    def decrease_difficulty(self):
        if self.difficulty > 0:
            self.difficulty -= 1
    
    def is_button_clicked(self, mouse_pos, button_rect):
        return button_rect.collidepoint(mouse_pos)

    def handle_resize(self, width, height):
        if not self.fullscreen:
            self.windowed_size = (width, height)
            self.screen = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)

    def toggle_fullscreen(self):
        if self.fullscreen:
            self.screen = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)
            self.fullscreen = False
        else:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            self.fullscreen = True

if __name__ == "__main__":
    app = MazeApp()
    app.run()
